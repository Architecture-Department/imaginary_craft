/*
 Copyright (c) 2022, Stephen Gold
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Neither the name of the copyright holder nor the names of its contributors
 may be used to endorse or promote products derived from this software without
 specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package jme3utilities.lbj;

import java.nio.FloatBuffer;

/**
 * A generic mesh for visualizing a soft body.
 *
 * @author Stephen Gold sgold@sonic.net
 */
public interface Mesh {
    // *************************************************************************
    // new methods exposed

    /**
     * Access the index buffer.
     *
     * @return the pre-existing instance (not null)
     */
    IndexBuffer getIndexBuffer();

    /**
     * Access the normals data buffer.
     *
     * @return the pre-existing direct buffer (not null)
     */
    FloatBuffer getNormalsData();

    /**
     * Access the positions data buffer.
     *
     * @return the pre-existing direct buffer (not null)
     */
    FloatBuffer getPositionsData();

    /**
     * Test whether the mesh consists of lines in list mode. In the context of
     * OpenGL, this means the draw mode is GL_LINES. Indexing is ignored.
     *
     * @return true if lines in list mode, otherwise false
     */
    boolean isPureLines();

    /**
     * Test whether the mesh consists of triangles in list mode. In the context
     * of OpenGL, this means the draw mode is GL_TRIANGLES. Indexing is ignored.
     *
     * @return true if triangles in list mode, otherwise false
     */
    boolean isPureTriangles();

    /**
     * Indicate that the normals data buffer is dirty.
     */
    void setNormalsModified();

    /**
     * Indicate that the positions data buffer is dirty.
     */
    void setPositionsModified();
}
